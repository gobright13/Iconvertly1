import AIAdLauncher from "@/components/AIAdLauncher";

export default function AIAdLauncherPage() {
  return <AIAdLauncher />;
}