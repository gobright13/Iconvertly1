import AIEmailSMSEngine from "@/components/AIEmailSMSEngine";

export default function AIEmailSMSEnginePage() {
  return <AIEmailSMSEngine />;
}