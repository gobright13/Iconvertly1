import AILaunchAssistant from "@/components/AILaunchAssistant";

export default function AILaunchAssistantPage() {
  return <AILaunchAssistant />;
}