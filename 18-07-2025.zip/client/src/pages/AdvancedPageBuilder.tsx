import AdvancedPageBuilder from "@/components/AdvancedPageBuilder";

export default function AdvancedPageBuilderPage() {
  return <AdvancedPageBuilder />;
}