import EmailSequenceBuilder from "@/components/EmailSequenceBuilder";

export default function EmailMarketing() {
  return <EmailSequenceBuilder />;
}